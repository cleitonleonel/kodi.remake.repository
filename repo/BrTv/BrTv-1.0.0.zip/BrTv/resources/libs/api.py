#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import requests

BASE_URL = 'https://tvlisa.com.br'


class Browser(object):

    def __init__(self):
        self.response = None
        self.session = requests.Session()

    @staticmethod
    def headers():
        base_headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                          " AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/87.0.4280.88 Safari/537.36"
        }
        return base_headers

    def send_request(self, method, url, **kwargs):
        with self.session as session:
            response = session.request(method, url, **kwargs)
        if response.status_code == 200:
            return response
        return None


class BrTvAPI(Browser):

    def __init__(self, email, password, token):
        super().__init__()
        self.headers = self.headers()
        self.email = email
        self.password = password
        self.token = token
        self.tvlisa_id = None

    def auth(self):
        data = {
            "email": self.email,
            "senha": self.password,
            "token": self.token
        }
        self.response = self.send_request('POST',
                                          BASE_URL + '/api/login.php',
                                          data=data,
                                          headers=self.headers
                                          )
        if self.response:
            self.tvlisa_id = self.response.json()[0]['object']['tvlisa_id']
            return self.response
        return False

    def get_menu(self):
        self.response = self.send_request('GET',
                                          BASE_URL + '/api/home.php',
                                          headers=self.headers
                                          )
        if self.response:
            return self.response
        return False

    def category_info(self, category_id):
        data = {
            "id_categoria": category_id,
            "tvlisa_id": self.tvlisa_id,
        }
        self.response = self.send_request('POST',
                                          BASE_URL + '/api/categoria.php',
                                          data=data,
                                          headers=self.headers
                                          )
        if self.response:
            return self.response
        return False

    def get_contents_info(self, sub_category_id):
        self.auth()
        data = {
            "id_categoria": sub_category_id,
            "tvlisa_id": self.tvlisa_id,
        }
        self.response = self.send_request('POST',
                                          BASE_URL + '/api/sub_categoria.php',
                                          data=data,
                                          headers=self.headers
                                          )
        if self.response:
            return self.response
        return False

    def get_reserved(self):
        self.auth()
        data = {
            "tvlisa_id": self.tvlisa_id,
        }
        self.response = self.send_request('POST',
                                          BASE_URL + '/api/reservado.php',
                                          data=data,
                                          headers=self.headers
                                          )
        if self.response:
            return self.response
        return False

    def search(self, name):
        self.auth()
        data = {
            "palavra": name,
            "tvlisa_id": self.tvlisa_id,
        }
        self.response = self.send_request('GET',
                                          BASE_URL + f'/api/busca.php',
                                          params=data,
                                          headers=self.headers
                                          )
        if self.response:
            return self.response
        return False
