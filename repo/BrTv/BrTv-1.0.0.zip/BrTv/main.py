#!/usr/bin/env python
# -*- coding: UTF-8 -*-
############################################################################################################
#                                         BIBLIOTECAS A IMPORTAR                                           #
############################################################################################################

import sys
import os
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from requests.utils import quote, unquote
from resources.libs.api import BrTvAPI

url = None
name = None
mode = None
iconimage = None
art = None
description = None
year = None
nota = None
genre = None
_id = None

############################################################################################################
#                                                  PARAMS                                                  #
############################################################################################################

versao = '0.0.1'
addon_id = 'BrTv'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
setting = xbmcaddon.Addon().getSetting
artfolder = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/img/'))
fanart = addonfolder + '/fanart.jpg'
server = 'https://www.tvlisa.com.br/'
username = selfAddon.getSetting('username')
password = selfAddon.getSetting('password')
token = selfAddon.getSetting('token')


def donate(img):
    wdlg = xbmcgui.WindowDialog()
    try:
        img = xbmcgui.ControlImage(450, 200, 400, 300, img)
        tmp_file = os.path.join(os.getcwd(), '/qrcode.png')
        wdlg.addControl(xbmcgui.ControlLabel(x=150, y=600, width=1000, height=25,
                                             label='SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX,'
                                                   ' LEIA O QRCODE ACIMA E MANTENHA ESSE SERVIÇO ATIVO',
                                             textColor='0xFFFFFFFF'))
        wdlg.addControl(img)
        wdlg.show()
        xbmc.sleep(15000)
    finally:
        wdlg.close()


if username == '' or password == '' or token == '':
    xbmcgui.Dialog().ok(addon_id, 'Se possui conta conosco insira os dados nas configurações...\n'
                                  'Se ainda não possui uma conta considere pagar um café a este humilde desenvolvedor.')
    selfAddon.openSettings()
    sys.exit(0)
else:
    pass

brtv = BrTvAPI(email=username, password=password, token=token)


############################################################################################################
#                                                   MENUS                                                  #
############################################################################################################

def login():
    authentication = brtv.auth().json()
    if authentication[0]['result']:
        xbmcgui.Dialog().notification(addon_id, 'Logado com sucesso !!!', time=2000,
                                      icon=selfAddon.getAddonInfo("path") + '/icon.png')
        return True

    return False


def start():
    client = login()
    if client:
        menus = brtv.get_menu().json()
        if menus[0]['result']:
            for menu in menus[0]['object']:
                addDir(f"[B]{menu['nome']}[/B]", menu['id'], 2, menu['imagem'], '', '-', '', '', '', '')
        addDir("[B]RESERVADOS[/B]", '-', 5, artfolder + 'reservado.png', '', '-', '', '', '', '', True)
        addDir("[B]PESQUISAR[/B]", '-', 6, artfolder + 'pesquisa.png', '', '-', '', '', '', '', True)
        addDir("[B]CONFIGURAÇÕES[/B]", '-', 7, artfolder + 'settings.png', '', '-', '', '', '', '', False)
        setViewFilmes()
    else:
        addLink("Apenas para assinantes do serviço fornecido por: [COLOR blue]http://www.tvlisa.com.br[/COLOR]",
                "-", "https://cdn0.iconfinder.com/data/icons/simple-web-navigation/165/574949-Exclamation-512.png")
        addLink("Ao que parece vc digitou um login inválido,verifique o login/senha e token inserido nas configurações"
                " do addon e tente novamente.", "-",
                "https://cdn0.iconfinder.com/data/icons/simple-web-navigation/165/574949-Exclamation-512.png")
        while xbmc.Player().isPlaying():
            time.sleep(1)


############################################################################################################
#                                                   MENU-FUNÇÕES                                           #
############################################################################################################


def get_category_info(category_id):
    category_info = brtv.category_info(category_id).json()
    for info in category_info[0]['object']:
        addDir(f"[B]{info['nome']}[/B]", info['id'], 3, info['imagem'], '', '-', '', '', '', '')
        setViewFilmes()


def get_contents(category_id):
    contents_info = brtv.get_contents_info(category_id).json()
    for item in contents_info[0]['object']:
        url = item['url']
        if item['url'] == '':
            url = '-'
        addDir(f"[B]{item['nome']}[/B]", url, 4, item['imagem'], '', item['sinopse'], item['ano'], '', '', '')
        setViewFilmes()


def view_contents(contents):
    for item in contents[0]['object']:
        url = item['url']
        if item['url'] == '':
            url = '-'
        addDir(f"[B]{item['nome']}[/B]", url, 4, item['imagem'], '', item['sinopse'], item['ano'], '', '', '')
        setViewFilmes()


def view_reserveds():
    contents = brtv.get_reserved().json()
    for item in contents[0]['object']:
        url = item['url']
        if item['url'] == '':
            url = '-'
        addDir(f"[B]{item['nome']}[/B]", url, 4, item['imagem'], '', item['sinopse'], item['ano'], '', '', '')
        setViewFilmes()


############################################################################################################
#                                                 MENU-PLAYER                                              #
############################################################################################################


def player(name, url, iconimage):
    if url != '-':
        dp = xbmcgui.DialogProgress()
        dp.create(addon_id, 'Resolvendo link para ' + name + '\nPor favor aguarde...')
        dp.update(0)
        playlist = xbmc.PlayList(0)
        playlist.clear()
        listitem = xbmcgui.ListItem(name)
        listitem.setArt({'icon': iconimage})
        listitem.setInfo("Video", {"Title": name})
        listitem.setProperty('mimetype', 'video/mp4')
        playlist.add(url, listitem)
        xbmcPlayer = xbmc.Player()
        dp.update(99)
        xbmcPlayer.play(url)
    else:
        xbmcgui.Dialog().ok(addon_id, f'Desculpe, {name} ainda não está disponível.')
    sys.exit(0)


############################################################################################################
#                                               CONFIGURAÇÕES                                              #
############################################################################################################


def settings():
    selfAddon.openSettings()
    sys.exit(0)


def search():
    keyb = xbmc.Keyboard('', 'Digite aqui item que deseja assistir...')
    keyb.doModal()
    if keyb.isConfirmed():
        query = keyb.getText()
        items = brtv.search(query).json()
        view_contents(items)
    else:
        return start()

    setViewFilmes()


def setViewMenu():
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    opcao = selfAddon.getSetting('menuVisu')
    if opcao == '0':
        xbmc.executebuiltin('Container.SetViewMode(50)')
    elif opcao == '1':
        xbmc.executebuiltin('Container.SetViewMode(51)')
    elif opcao == '2':
        xbmc.executebuiltin('Container.SetViewMode(500)')


def setViewFilmes():
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    opcao = selfAddon.getSetting('filmesVisu')
    if opcao == '0':
        xbmc.executebuiltin('Container.SetViewMode(50)')
    elif opcao == '1':
        xbmc.executebuiltin('Container.SetViewMode(51)')
    elif opcao == '2':
        xbmc.executebuiltin('Container.SetViewMode(500)')
    elif opcao == '3':
        xbmc.executebuiltin('Container.SetViewMode(501)')
    elif opcao == '4':
        xbmc.executebuiltin('Container.SetViewMode(508)')
    elif opcao == '5':
        xbmc.executebuiltin('Container.SetViewMode(504)')
    elif opcao == '6':
        xbmc.executebuiltin('Container.SetViewMode(503)')
    elif opcao == '7':
        xbmc.executebuiltin('Container.SetViewMode(515)')


############################################################################################################
#                                                 FUNÇÕES                                                  #
############################################################################################################


def addDir(name, url, mode, iconimage, art, description, year, genre, nota, _id, pasta=True, total=1):
    u = f'{sys.argv[0]}?url={quote(url)}&mode={str(mode)}&name={quote(name)}&iconimage={quote(iconimage)}' \
        f'&art={quote(art)}&id={quote(_id)}&description={quote(description)}'
    sysaddon = sys.argv[0]
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': selfAddon.getAddonInfo("path") + '/icon.png', "thumb": iconimage})
    liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description,
                                          'Rating': nota, 'Genre': genre, 'Year': year})
    liz.setProperty('fanart_image', art)
    contextMenuItems = [('Movie Information', 'RunPlugin(%s?action=addView&content=movies)' % sysaddon)]
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=pasta, totalItems=total)
    return ok


def addLink(name, url, iconimage):
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': selfAddon.getAddonInfo("path") + '/icon.png', "thumb": iconimage})
    liz.setProperty('fanart_image', fanart)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz)
    return ok


############################################################################################################
#                                               GET PARAMS                                                 #
############################################################################################################


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            if "=" not in pairsofparams[i]:
                pairsofparams[i] = pairsofparams[i] + "="
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
if isinstance(params, dict):
    url = unquote(params["url"])
    name = unquote(params["name"])
    iconimage = unquote(params["iconimage"])
    mode = int(params["mode"])
    description = unquote(params["description"])

print("Mode: " + str(mode))
print("URL: " + str(url))
print("Name: " + str(name))
print("Iconimage: " + str(iconimage))
print('Art: ' + str(art))
print('Description: ' + str(description))
print('Year: ' + str(year))
print('Genre: ' + str(genre))
print('Nota: ' + str(nota))
print("ID: " + str(_id))

###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################

if mode is None or url is None or len(url) < 1:
    donate(artfolder + '/qrcode.png')
    start()

elif mode == 2:
    get_category_info(url)

elif mode == 3:
    get_contents(url)

elif mode == 4:
    player(name, url, iconimage)

elif mode == 5:
    view_reserveds()

elif mode == 6:
    search()

elif mode == 7:
    settings()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
