# -*- coding: utf-8 -*-
#
import sys
import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin
import rcresolver
from rcresolver.resolver import Browser
from bs4 import BeautifulSoup
from requests.utils import quote, unquote

addon = xbmcaddon.Addon()
home = xbmc.translatePath(addon.getAddonInfo('path'))
addonname = addon.getAddonInfo('name')
wdlg = None


def donate(img):
    global wdlg
    try:
        wdlg = xbmcgui.WindowDialog()
        img = xbmcgui.ControlImage(450, 200, 400, 300, img)
        wdlg.addControl(xbmcgui.ControlLabel(x=150, y=600, width=1000, height=25,
                                             label='SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX,'
                                                   ' LEIA O QRCODE ACIMA E MANTENHA ESSE SERVIÇO ATIVO',
                                             textColor='0xFFFFFFFF'))
        wdlg.addControl(img)
        wdlg.show()
        xbmc.sleep(15000)
    finally:
        wdlg.close()


def play(name, url, iconimage):
    stream = rcresolver.resolve(url)
    xbmcgui.Dialog().ok(addonname, stream['stream'])
    playlist = xbmc.PlayList(0)
    playlist.clear()
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'icon': iconimage})
    listitem.setInfo("Video", {"Title": name})
    listitem.setProperty('mimetype', 'video/mp4')
    playlist.add(stream['stream'], listitem)
    xbmcPlayer = xbmc.Player()
    xbmcPlayer.play(stream['stream'] + '|Referer=' + stream['referer'])
    sys.exit()


def get_description(url):
    html = Browser().send_request('GET', url)
    soup = BeautifulSoup(html, 'html.parser')
    try:
        tags = soup.find('div', {'id': 'content-main'})
        films = tags.find_all('div', {'itemprop': 'description'})
        if not films:
            result = 'Conteúdo sem descrição!!!'
            return result
        else:
            for info in films:
                result = info.text.replace('\n', '')
                return result
    except:
        return 'Conteúdo sem descrição!!!'


def search_items(url_server, url, data, description=None):
    BASE_URL = url_server
    html = Browser().send_request('POST', url, data=data)
    soup = BeautifulSoup(html, 'html.parser')
    films = soup.find_all('li')
    films_list = []

    if len(films) == 0:
        url = url_server + '/search.php?keywords=' + data['queryString'] + '&video-id='
        return films_per_genre(url_server, url)

    for info in films:
        if ' - Episódio' not in info.a.text:
            result = info.a
            if description:
                description = get_description(BASE_URL + result['href'])
            else:
                description = None
            dict_films = {'title': result.text, 'url': BASE_URL + result['href'], 'img': '', 'description': description}
            films_list.append(dict_films)
        else:
            result = info.a
            dict_films = {'title': result.text, 'url': BASE_URL + result['href'], 'img': '', 'description': ''}
            films_list.append(dict_films)

    return films_list


def films_per_genre(url_server, url):
    BASE_URL = url_server
    html = Browser().send_request('GET', url)
    soup = BeautifulSoup(html, 'html.parser')
    tags = soup.find('ul', {'class': 'row pm-ul-browse-videos list-unstyled'})
    films = tags.find_all('div', {'class': 'pm-video-thumb'})
    films_list = []
    for info in films:
        result = info.find_all('a')[1]
        if 'https' not in result.img['data-echo']:
            img = BASE_URL + result.img['data-echo']
        else:
            img = result.img['data-echo']
        description = get_description(BASE_URL + result['href'])
        dict_films = {'title': result.img['alt'], 'url': BASE_URL + result['href'], 'img': img,
                      'description': description}
        films_list.append(dict_films)
    return films_list


def search(url_server, parameter):
    film_name = parameter.capitalize()
    data = {"queryString": film_name}
    url_search = f'{url_server}/ajax_search.php'
    return search_items(url_server, url_search, data)


def set_film():
    keyb = xbmc.Keyboard('', 'Search Film')
    keyb.doModal()
    if (keyb.isConfirmed()):
        return quote(keyb.getText())
    else:
        return


def set_channel():
    keyb = xbmc.Keyboard('', 'Search Channel')
    keyb.doModal()
    if (keyb.isConfirmed()):
        return quote(keyb.getText())
    else:
        return


def set_params():
    dialog = xbmcgui.Dialog()
    funcs = (
        _film0,
        _channel1,
    )
    call = dialog.select('Stream Resolver', ['Buscar Filme', 'Buscar Canal'])
    if call > -1:
        func = funcs[call]
        return func()


def _film0():
    url_server = 'https://redecanais.cloud'
    film_name = set_film()
    films = search(url_server, film_name)
    for film in films:
        title = film['title']
        url = film['url']
        img = film['img']
        addDirf(title, url, 1, img, False)


def _channel1():
    url_server = 'https://redecanaistv.com'
    channel_name = set_channel()
    channels = search(url_server, channel_name)
    for channel in channels:
        title = channel['title']
        url = channel['url']
        img = channel['img']
        addDirf(title, url, 1, img, False)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


def addDirf(name, url, mode, iconimage, pasta=True, total=1, plot=''):
    u = sys.argv[0] + "?url=" + quote(url) + "&mode=" + str(mode) + "&name=" + quote(name) + "&iconimage=" + quote(
        iconimage)
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': addon.getAddonInfo("path") + '/SEARCHS.png'})
    liz.setProperty('fanart_image', iconimage)
    liz.setInfo(type="video", infoLabels={"title": name, "plot": plot})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=pasta, totalItems=total)
    return ok


params = get_params()
url = None
name = None
mode = None
iconimage = None
description = None
site = None

try:
    url = unquote(params["url"])
except:
    pass
try:
    name = unquote(params["name"])
except:
    pass
try:
    iconimage = unquote(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass
try:
    description = unquote(params["description"])
except:
    pass

if mode is None or url is None or len(url) < 1:
    donate(home + '/qrcode.png')
    set_params()

elif mode == 1:
    play(name, url, iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
