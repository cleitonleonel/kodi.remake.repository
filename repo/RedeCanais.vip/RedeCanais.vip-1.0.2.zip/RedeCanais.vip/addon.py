#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
import sys
import os
import re
import xbmcplugin
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
import threading
import rcresolver
from bs4 import BeautifulSoup
from requests.utils import quote, unquote
from datetime import datetime, date, timedelta
from rcresolver.resolver import Browser, LocalHttpProxy

addon_id = 'RedeCanais.vip'
addon_name = 'Rede Canais'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
art = xbmcvfs.translatePath(os.path.join(f'special://home/addons/{addon_id}/resources/art/'))
icon = addonfolder + '/icon.png'
fanart = addonfolder + '/fanart.jpg'
url_server = 'https://redecanais.re'
url_server_tv = 'https://redecanaistv.net'
url = None
name = None
mode = None
iconimage = None
description = None
site = None
browser = Browser()
monitor = xbmc.Monitor()


def menu():
    # intro = Ver_intro()
    addDir("[B]" + 'Filmes' + "[/B]", url_server + '/browse-filmes-videos-1-date.html', 2, art + 'FILMES.jpg', art + 'FILMES.jpg', '')
    addDir("[B]" + 'Séries' + "[/B]", url_server + '/browse-series-videos-1-date.html', 7, art + 'SERIES.jpg', art + 'SERIES.jpg', '')
    addDir("[B]" + 'Animes' + "[/B]", url_server + '/browse-animes-videos-1-date.html', 7, art + 'ANIMES.png', art + 'ANIMES.png', '')
    addDir("[B]" + 'Desenhos' + "[/B]", url_server + '/browse-desenhos-videos-1-date.html', 7, art + 'DESENHOS.png', art + 'DESENHOS.png', '')
    addDir("[B]" + 'Tv' + "[/B]", url_server_tv + '/browse.html', 11, art + 'TV.jpg', art + 'TV.jpg', '')
    addDir("[B]" + 'Pesquisar Filmes' + "[/B]", '-', 6, art + 'SEARCHS.png', art + 'SEARCHS.png', '')
    addDir("[B]Configurações[/B]", '-', 104, art + 'SETTINGS.png', art + 'SETTINGS.png', '')
    # while xbmc.Player().isPlaying():
    # ftoday = open(os.path.join(xbmcvfs.translatePath("special://temp"), "today"), 'w')
    # today = str(date.today())
    # ftoday.write(today)
    # ftoday.close()
    # time.sleep(1)
    setViewMenu()


# NÃO IMPLEMENTADO
def intro_view():
    if os.path.exists(os.path.join(xbmcvfs.translatePath("special://temp"), "today")):
        ftoday = open(os.path.join(xbmcvfs.translatePath("special://temp"), "today")).read()
        today = str(date.today())
    else:
        ftoday = ''
        today = str(date.today())
    if ftoday != today:
        # xbmc.Player().play(str(artfolder)+'intro.mkv')
        # xbmc.Player().play('')
        return True


def donate(img):
    wdlg = xbmcgui.WindowDialog()
    try:
        img = xbmcgui.ControlImage(450, 200, 400, 300, img)
        tmp_file = os.path.join(os.getcwd(), '/qrcode.png')
        wdlg.addControl(xbmcgui.ControlLabel(x=150,
                                             y=600,
                                             width=1000,
                                             height=25,
                                             label='SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX, LEIA O QRCODE '
                                                   'ACIMA E MANTENHA ESSE SERVIÇO ATIVO',
                                             textColor='0xFFFFFFFF'))
        wdlg.addControl(img)
        wdlg.show()
        xbmc.sleep(15000)
    finally:
        wdlg.close()


def change_list(data):
    films_list = []
    for item in data:
        result_dict = {}
        result = item.find_all('a')[1]
        result_dict['url'] = url_server + result["href"]
        result_dict['name'] = result.img["alt"]
        result_dict['img'] = url_server + result.img['data-echo']
        films_list.append(result_dict)
    new_list = sorted(films_list, key=lambda x: x['name'])
    return new_list


def get_all_categories_films(url):
    html = get_soup_html(url)
    soup = html.find("ul", {"class": "dropdown-menu"})
    categorias = soup.findAll("li")
    for categoria in categorias:
        titulo = categoria.a.text
        url = categoria.a["href"]
        if 'Lançamentos' in titulo or 'Filmes 2020' in titulo:
            addDir('[COLOR white]'"[B]" + titulo + "[/B]"'[/COLOR]', url_server + url, 4, art + 'fllmes2.png', art + 'cinema2.jpg', '')
        else:
            addDir('[COLOR white]'"[B]" + titulo + "[/B]"'[/COLOR]', url_server + url, 3, art + 'fllmes2.png', art + 'cinema2.jpg', '')
    setViewFilmes()


def sub_categories_filme(url):
    html = get_soup_html(url)
    soup = html.find("div", {"class": "pm-category-subcats"})
    categorias = soup.findAll("ul", {"class": "list-inline"})
    for cat in categorias:
        categoria = re.compile(r'<li><a href="(.*?)">(.*?)</a></li>').findall(str(cat))
        if len(categoria) > 0:
            for url, titulo_cat in categoria:
                addDir(titulo_cat, url_server + url, 4, art + 'filmes.png', art + 'filmes3.png', '')
    setViewFilmes()


def get_contents(url):
    if 'search' in url:
        next = re.compile(r'https://.*?re/search.*?keywords=.*?&page=(.*?)$').findall(url)[0]
        page = '%s&page=%s' % (url.split('&page=', 1)[0], str(int(next) + 1))
    else:
        category = re.compile(r'(.*?)-videos-.*?.html').findall(url)[0]
        next = re.compile(r'.*?videos-(.*?)-.*?html').findall(url)[0]
        page = str(category) + '-videos-' + str(int(next) + 1) + '-date.html'
    try:
        html = get_soup_html(url)
        tag_list = html.find("ul", {"class": "row pm-ul-browse-videos list-unstyled"})
        films = tag_list.find_all('div', {'class': 'pm-video-thumb'})
        for index, film in enumerate(films):
            if 'temporada' in url:
                items = change_list(films)
                url = items[index]['url']
                name = items[index]['name']
                img = items[index]['img']
            else:
                result = film.find_all('a')[1]
                url = url_server + result["href"]
                name = result.img["alt"]
                img = url_server + result.img['data-echo']
            addDir(name, url, 5, img, img, '')
        if html.find("ul", {"class": "pagination"}):
            addDir('[COLOR maroon][B]Próxima Página>>> [/B][/COLOR]', page, 4, art + 'next.png', '', '')
    except:
        addDir("[B]" + 'Desculpe, NÃO existe NENHUM Título nesta Categoria no Momento.' + "[/B]", '', '', '', '', '')
    setViewFilmes()


def get_image_art(url):
    try:
        html = get_soup_html(url)
        return html.find("div", {"class": "pm-category-description"}).p.img["src"]
    except:
        return ''


def get_by_letter(url):
    html = get_soup_html(url)
    list_letters = html.find("div", {"class": "row pm-category-header-subcats"})
    letters = list_letters.find_all("li")
    for letter in letters:
        url = letter.a["href"]
        addDir("[B]" + letter.text + "[/B]", url_server + url, 8, art + 'filmes.png', '', '')
    setViewFilmes()


def get_items(url):
    html = get_soup_html(url)
    list_series = html.find("div", {"class": "pm-category-description"})
    series = list_series.find_all("a")
    titles = list_series.p.text.replace('Assistir', 'Acessar').split(' - Acessar')
    for index, serie in enumerate(series):
        title = titles[index]
        url = serie["href"]
        addDir("[B]" + title + "[/B]", url_server + url, 9, '', '', '')
    setViewFilmes()


def set_language(url):
    img = get_image_art(url)
    html = get_soup_html(url)
    list_categories = html.find("div", {"class": "pm-category-subcats"})
    categorias = list_categories.find_all("li")
    for categoria in categorias:
        url = categoria.a["href"]
        title = categoria.a.text
        addDir("[B]" + title + "[/B]", url_server + url, 10, url_server + img, url_server + img, '')
    setViewFilmes()


def get_seasons(url, img):
    html = get_soup_html(url)
    try:
        list_seasons = html.find("div", {"class": "pm-category-subcats"})
        temporadas = list_seasons.find_all("li")
        for temporada in temporadas:
            url = temporada.a["href"]
            title = temporada.a.text
            addDir("[B]" + title + "[/B]", url_server + url, 4, img, img, '')
    except:
        get_contents(url)
    setViewFilmes()


def player(name, url, iconimage):
    dp = xbmcgui.DialogProgress()
    dp.create(addon_id, 'Resolvendo link para ' + name + '\nPor favor aguarde...')
    dp.update(0)
    dp.update(30)
    playlist = xbmc.PlayList(0)
    playlist.clear()
    stream = rcresolver.resolve(url)
    dp.update(55)
    if 'm3u8' in stream['source'] or '%<\\>/i/e/s/*' in stream['source']:
        dp.update(70)
        m3u_path = rcresolver.make_m3u(stream['source'])
        xbmc.executebuiltin('PlayerControl(RepeatOff)')
        dp.update(75)
        listitem = xbmcgui.ListItem(name, path=m3u_path)
        listitem.setArt({"icon": iconimage, "thumb": iconimage})
        listitem.setInfo(type='video', infoLabels={'Title': name, 'plot': description})
        dp.update(80)
        listitem.setProperty('inputstream', 'inputstream.ffmpegdirect')
        listitem.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        dp.update(99)
        dp.update(100)
        dp.close()
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
        http_server()
    else:
        dp.update(70)
        listitem = xbmcgui.ListItem(name)
        listitem.setArt({'icon': iconimage})
        dp.update(75)
        listitem.setInfo("Video", {"Title": name})
        listitem.setProperty('mimetype', 'video/mp4')
        dp.update(80)
        playlist.add(stream['download'], listitem)
        dp.update(99)
        xbmcPlayer = xbmc.Player()
        dp.update(100)
        dp.close()
        stream_play = f'{stream["download"]}|Referer={stream["referer"]}' \
                      f'&User-Agent={browser.headers()["User-Agent"]}&verifypeer=false'
        xbmcPlayer.play(stream_play)


def get_tv_categories(url):
    html = get_soup_html(url)
    list_series = html.find("ul", {"class": "pm-ul-browse-categories list-unstyled thumbnails"})
    categories = list_series.find_all("li")
    for category in categories:
        title = category.img['alt']
        url = category.a["href"]
        addDir("[B]" + title + "[/B]", url_server_tv + url, 12, '', '', '')
    setViewFilmes()


def get_channels(url):
    category = re.compile(r'(.*?)-videos-.*?.html').findall(url)[0]
    next = re.compile(r'.*?videos-(.*?)-.*?html').findall(url)[0]
    page = str(category) + '-videos-' + str(int(next) + 1) + '-date.html'
    try:
        html = get_soup_html(url)
        tag_list = html.find("ul", {"class": "row pm-ul-browse-videos list-unstyled"})
        channels = tag_list.find_all('div', {'class': 'pm-video-thumb'})
        for channel in channels:
            result = channel.find_all('a')[1]
            url = url_server_tv + result["href"]
            name = result.img["alt"]
            img = url_server_tv + result.img['data-echo']
            addDir(name, url, 5, img, img, '')
        if html.find("ul", {"class": "pagination"}):
            addDir('[COLOR maroon][B]Próxima Página>>> [/B][/COLOR]', page, 12, art + 'next.png', '', '')
    except:
        addDir("[B]" + 'Desculpe, NÃO existe NENHUM Título nesta Categoria no Momento.' + "[/B]", '', '', '', '', '')
    setViewFilmes()


def search():
    keyb = xbmc.Keyboard('', 'Digite o Filme Desejado...')
    keyb.doModal()
    if keyb.isConfirmed():
        query = keyb.getText().capitalize()
        url = f'https://redecanais.re/search.php?keywords={quote(query)}&page=1'
        get_contents(url)
    else:
        return menu()
    setViewFilmes()


def settings():
    selfAddon.openSettings()
    # setViewMenu()
    sys.exit(0)


def setViewMenu():
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    opcao = selfAddon.getSetting('menuVisu')
    if opcao == '0':
        xbmc.executebuiltin('Container.SetViewMode(500)')
    elif opcao == '1':
        xbmc.executebuiltin('Container.SetViewMode(501)')
    elif opcao == '2':
        xbmc.executebuiltin('Container.SetViewMode(502)')


def setViewFilmes():
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    opcao = selfAddon.getSetting('filmesVisu')
    if opcao == '0':
        xbmc.executebuiltin('Container.SetViewMode(50)')
    elif opcao == '1':
        xbmc.executebuiltin('Container.SetViewMode(51)')
    elif opcao == '2':
        xbmc.executebuiltin('Container.SetViewMode(52)')
    elif opcao == '3':
        xbmc.executebuiltin('Container.SetViewMode(53)')
    elif opcao == '4':
        xbmc.executebuiltin('Container.SetViewMode(54)')
    elif opcao == '5':
        xbmc.executebuiltin('Container.SetViewMode(55)')
    elif opcao == '6':
        xbmc.executebuiltin('Container.SetViewMode(500)')
    elif opcao == '7':
        xbmc.executebuiltin('Container.SetViewMode(501)')
    elif opcao == '8':
        xbmc.executebuiltin('Container.SetViewMode(502)')


def addDir(name, url, mode, iconimage, fanart, description, pasta=False, total=1):
    u = sys.argv[0] + "?url=" + quote(url) + "&mode=" + str(mode) + "&name=" + quote(name) + "&iconimage=" + quote(iconimage) + "&description=" + quote(description)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': selfAddon.getAddonInfo("path") + '/DefaultFolder.png', "thumb": iconimage})
    liz.setProperty('fanart_image', fanart)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    if mode == 1 or mode == 5:
        liz.setProperty("IsPlayable", "true")
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=pasta, totalItems=total)
    else:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True, totalItems=total)
    return ok


def addDir1(name, url, mode, iconimage, pasta=True, total=1, plot=''):
    u = sys.argv[0] + "?url=" + quote(url) + "&mode=" + str(mode) + "&name=" + quote(name) + "&iconimage=" + quote(iconimage)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': selfAddon.getAddonInfo("path") + '/SEARCHS.png'})
    liz.setProperty('fanart_image', iconimage)
    liz.setInfo(type="video", infoLabels={"title": name, "plot": plot})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=pasta, totalItems=total)
    return ok


def addDir2(name, url, mode, iconimage, pasta=True, total=1, plot=''):
    u = sys.argv[0] + "?url=" + quote(url) + "&mode=" + str(mode) + "&name=" + quote(name) + "&iconimage=" + quote(iconimage)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': selfAddon.getAddonInfo("path") + '/DefaultFolder.png', "thumb": iconimage})
    liz.setArt({'icon': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=pasta, totalItems=total)
    return ok


def addLink(name, url, mode, iconimage, fanart, description, genre, date, folder=False):
    if mode > 1:
        u = sys.argv[0] + "?url=" + quote(url) + "&mode=" + str(mode) + "&name=" + quote(
            name) + "&iconimage=" + quote(iconimage) + "&description=" + quote(str(description))
    else:
        u = url
    if date == '':
        date = None
    else:
        description += '\n\nDate: %s' % date
    if iconimage > '':
        thumbnail = iconimage
    else:
        thumbnail = 'DefaultVideo.png'
    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": thumbnail})
    if mode == 11 or url == 'here':
        li.setProperty('IsPlayable', 'false')
    else:
        li.setProperty('IsPlayable', 'true')
    if fanart > '':
        li.setProperty('fanart_image', fanart)
    li.setInfo('video', {'plot': description})
    try:
        li.setInfo('video', {'genre': str(genre)})
    except:
        pass
    try:
        li.setInfo('video', {'dateadded': str(date)})
    except:
        pass
    try:
        li.setInfo('video', {'year': int(date)})
    except:
        pass
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)


def addLink1(name, url, iconimage, folder=False):
    liz = xbmcgui.ListItem(name)
    liz.setProperty('fanart_image', fanart)
    liz.setArt({'icon': iconimage})
    liz.setInfo(type='Video', infoLabels={'Title': name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz, isFolder=folder)
    return ok


def get_soup_html(url):
    headers = browser.headers()
    response = browser.send_request('GET', url, headers=headers)
    return BeautifulSoup(response.text, "html.parser")


def open_url(url):
    headers = browser.headers()
    return browser.send_request('GET', url, headers=headers).text


def http_server():
    try:
        server = LocalHttpProxy()
        server.set_config('127.0.0.1', 3333)
        server_thread = threading.Thread(target=server.runserver)
        server_thread.start()
        while not monitor.waitForAbort(2):
            pass
        server.shutdown()
        server_thread.join()
    except:
        pass


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            if "=" not in pairsofparams[i]:
                pairsofparams[i] = pairsofparams[i] + "="
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
if isinstance(params, dict):
    url = unquote(params["url"])
    name = unquote(params["name"])
    iconimage = unquote(params["iconimage"])
    mode = int(params["mode"])
    description = unquote(params["description"])

if not mode or not url or len(url) < 1:
    donate(art + '/qrcode.png')
    xbmcgui.Dialog().notification(addon_id, 'Logado com sucesso !!!', time=2000, icon=icon)
    menu()

elif mode == 2:
    get_all_categories_films(url)

elif mode == 3:
    sub_categories_filme(url)

elif mode == 4:
    get_contents(url)

elif mode == 5:
    player(name, url, iconimage)

elif mode == 6:
    search()

elif mode == 7:
    get_by_letter(url)

elif mode == 8:
    get_items(url)

elif mode == 9:
    set_language(url)

elif mode == 10:
    get_seasons(url, iconimage)

elif mode == 11:
    get_tv_categories(url)

elif mode == 12:
    get_channels(url)

elif mode == 104:
    settings()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
